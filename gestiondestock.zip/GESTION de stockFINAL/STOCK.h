#pragma once

typedef struct {
    int jour;
    int mois;
    int annee;
} Date;

typedef struct {
    int id;
    char nom[100];
    char description[100];
    char nom_u[50]; //nom dutilisateur
    float prix;
    int quantite;
    Date date;
    Date date2;
    float seuil;
} produit;

// Function declarations
int authentifier(const char* fichiernom, char nom_utilisateur[], char mot_de_passe[]);
void modifierProduit(const char* fichier, char* nomProduit);
void ajouterProduit(const char* fichier);
void supprimerProduit(const char* fichier, char* nomProduit);
void rechercherProduit(const char* fichier, char critere[],int option);
void afficherListeProduits(const char* fichier);
int trierParPrix(const char* fichier);
void trierParNom(const char* fichier);
int lireProduits(const char* fichier, produit produits[]);
