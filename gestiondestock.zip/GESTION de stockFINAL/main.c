#include <stdio.h>
#include <stdlib.h>
#include "STOCK.h"

int main() {
    char motDePasse[30], nom[50];
    int choixUtilisateur, option;
    int choixAction, tentatives = 0;
    char produitRecherche[30], critere[30];
    const char* nomClient = "utilisateur.csv";
    const char* nomGerant = "gerant.csv";
    const char* nomStock = "stock.csv";

    printf("-----------***********-----------\n");
    printf("  Bienvenue dans le gestionnaire de stock\n");
    printf("-----------***********-----------\n");

    printf("Choisissez si vous �tes un client ou un g�rant\n");
    printf("1. G�rant\n");
    printf("2. Client\n");
    printf("3. Quitter\n");
    printf("Votre choix : ");
    scanf("%d", &choixUtilisateur);

    //il kan gerant
    if (choixUtilisateur == 1) {
        while (tentatives < 3) {
            printf("\n--- Authentification G�rant ---\n");
            printf("Entrez votre nom : ");
            scanf("%s", nom);
            printf("Entrez votre mot de passe : ");
            scanf("%s", motDePasse);

            if (authentifier(nomGerant, nom, motDePasse) == 1) {
                printf("\nAuthentification r�ussie.\n");
                choixAction = 0;

                while (choixAction != 7) {
                    printf("\n------------ Menu G�rant ------------\n");
                    printf("1. Ajouter un produit\n");
                    printf("2. Modifier un produit\n");
                    printf("3. Supprimer un produit\n");
                    printf("4. Trier par ordre alphab�tique\n");
                    printf("5. Trier par prix\n");
                    printf("6. Rechercher un produit\n");
                    printf("7. Quitter\n");
                    printf("Votre choix : ");
                    scanf("%d", &choixAction);

                    switch (choixAction) {
                        case 1:
                            ajouterProduit(nomStock);
                            break;
                        case 2:
                            printf("\nDonner le nom du produit � modifier : ");
                            scanf("%s", produitRecherche);
                            modifierProduit(nomStock, produitRecherche);
                            break;
                        case 3:
                            printf("\nDonner le nom du produit � supprimer : ");
                            scanf("%s", produitRecherche);
                            supprimerProduit(nomStock, produitRecherche);
                            break;
                        case 4:
                            trierParNom(nomStock);
                            break;
                        case 5:
                            trierParPrix(nomStock);
                            break;
                        case 6:
                            printf("Choisir une option :\n");
                            printf("1. Rechercher par nom de produit\n");
                            printf("2. Rechercher par nom d'utilisateur\n");
                            scanf("%d", &option);
                            if (option == 1) {
                                printf("\nDonner le nom du produit � rechercher : ");
                                scanf("%s", produitRecherche);
                                rechercherProduit(nomStock, produitRecherche, option);
                            } else if (option == 2) {
                                printf("Donner le nom d'utilisateur : ");
                                scanf("%s", produitRecherche); // Utilis� pour la recherche par utilisateur
                                rechercherProduit(nomStock, produitRecherche, option);
                            }
                            break;
                        case 7:
                            printf("Au revoir, g�rant!\n");
                            return 0;
                        default:
                            printf("Choix invalide! Veuillez r�essayer.\n");
                    }

                    printf("\nAppuyez sur Entr�e pour continuer...");
                    getchar();
                    getchar();
                }
                break;
            } else {
                printf("Authentification �chou�e. Veuillez r�essayer.\n");
                tentatives++;
                if (tentatives == 3) {
                    printf("Nombre maximal de tentatives atteint. Le programme va se fermer.\n");
                    return 1;
                }
            }
        }
    }
    // un client
    else if (choixUtilisateur == 2) {
        while (tentatives < 3) {
            printf("\n--- Authentification Client ---\n");
            printf("Entrez votre nom : ");
            scanf("%s", nom);
            printf("Entrez votre mot de passe : ");
            scanf("%s", motDePasse);

            if (authentifier(nomClient, nom, motDePasse) == 1) {
                printf("\nAuthentification r�ussie.\n");
                choixAction = 0;

                while (choixAction != 4) {
                    printf("\n------------ Menu Client ------------\n");
                    printf("1. Afficher tous les produits\n");
                    printf("2. Rechercher un produit\n");
                    printf("3. Trier par prix\n");
                    printf("4. Quitter\n");
                    printf("Votre choix : ");
                    scanf("%d", &choixAction);

                    switch (choixAction) {
                        case 1:
                            afficherListeProduits(nomStock);
                            break;
                        case 2:
                            printf("\nDonner le nom du produit � rechercher : ");
                            scanf("%s", produitRecherche);
                            rechercherProduit(nomStock, produitRecherche, 1); // Recherche par nom
                            break;
                        case 3:
                            trierParPrix(nomStock);
                            break;
                        case 4:
                            printf("Au revoir, client!\n");
                            return 0;
                        default:
                            printf("Choix invalide! Veuillez r�essayer.\n");
                    }

                    printf("\nAppuyez sur Entr�e pour continuer");
                    getchar();
                    getchar();
                }
                break;
            } else {
                printf("Authentification �chou�e. Veuillez r�essayer.\n");
                tentatives++;
                if (tentatives == 3) {
                    printf("Nombre maximal de tentatives atteint. Le programme va se fermer.\n");
                    return 1;
                }
            }
        }
    }

    else if (choixUtilisateur == 3) {
        printf("Au revoir!\n");
        return 0;
    } else {
        printf("Choix non valide. Le programme va se fermer.\n");
    }

    return 0;
}
