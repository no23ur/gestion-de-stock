#include <stdio.h>
#include <string.h>
#include "STOCK.h"


int lireProduits(const char* fichier, produit produits[]) {
    FILE* f = fopen(fichier, "r");
    if (f == NULL) {
        printf("Erreur d'ouverture du fichier %s\n", fichier);
        return 0;
    }

    int i = 0;
    while (fscanf(f, "%d,%[^,],%[^,],%[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
                  &produits[i].id,
                  produits[i].nom,
                  produits[i].description,
                  produits[i].nom_u,
                  &produits[i].prix,
                  &produits[i].quantite,
                  &produits[i].date.jour, &produits[i].date.mois, &produits[i].date.annee,
                  &produits[i].date2.jour, &produits[i].date2.mois, &produits[i].date2.annee,
                  &produits[i].seuil) == 13) {
        i++;
    }
    fclose(f);
    return i;
}

int authentifier(const char* fichiernom, char nom_utilisateur[], char mot_de_passe[]) {
    FILE* stock = fopen(fichiernom, "r");
    if (stock == NULL) {
        printf("Erreur: Impossible d'ouvrir le fichier %s\n", fichiernom);
        return 0;
    }

    char ligne[100];
    char utilisateur[30];
    char mdp[20];

    while (fgets(ligne, sizeof(ligne), stock)) {
        ligne[strcspn(ligne, "\n")] = 0;
        if (sscanf(ligne, "%[^,],%s", utilisateur, mdp) == 2) {
            if (strcmp(nom_utilisateur, utilisateur) == 0 && strcmp(mot_de_passe, mdp) == 0) {
                fclose(stock);
                return 1;
            }
        }
    }

    fclose(stock);
    return 0;
}

void ajouterProduit(const char* fichier) {
    FILE* file = fopen(fichier, "a");
    if (file == NULL) {
        printf("Erreur d'ouverture du fichier %s\n", fichier);
        return;
    }

     produit p;

    printf("Entrez l'ID du produit: \n ");
    scanf("%d", &p.id);
    getchar();

    printf("Entrez le nom du produit: ");
    scanf(" %s", p.nom);
getchar();
    printf("Entrez la description du produit: ");
    scanf(" %s", p.description);
getchar();
    printf("Entrez le nom de l'utilisateur: ");
    scanf(" %s", p.nom_u);
getchar();
    printf("Entrez le prix du produit: ");
    scanf("%f", &p.prix);

    printf("Entrez la quantit� disponible: ");
    scanf("%d", &p.quantite);

    printf("Entrez la date de fabrication (jj mm aaaa): ");
    scanf("%d %d %d", &p.date.jour, &p.date.mois, &p.date.annee);

    printf("Entrez la date d'expiration (jj mm aaaa): ");
    scanf("%d %d %d", &p.date2.jour, &p.date2.mois, &p.date2.annee);

    printf("Entrez le seuil de stock: ");
    scanf("%f", &p.seuil);


    fprintf(file, "%d,%s,%s,%s,%.2f,%d,%02d/%02d/%04d,%02d/%02d/%04d,%.2f\n",
            p.id, p.nom, p.description, p.nom_u, p.prix, p.quantite,
            p.date.jour, p.date.mois, p.date.annee,
            p.date2.jour, p.date2.mois, p.date2.annee, p.seuil);

    fclose(file);
    printf("Produit ajout� avec succ�s!\n");
}

void modifierProduit(const char* fichier, char* nomProduit) {
    FILE* f = fopen(fichier, "r");
    if (f == NULL) {
        printf("Erreur: Impossible d'ouvrir le fichier %s\n", fichier);
        return;
    }

    FILE* temp = fopen("temp.csv", "w");
    if (temp == NULL) {
        printf("Erreur: Impossible de cr�er le fichier temporaire\n");
        fclose(f);
        return;
    }

    produit p;
    int trouve = 0;

    while (fscanf(f, "%d,%[^,],%[^,],%[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
                &p.id, p.nom, p.description, p.nom_u, &p.prix, &p.quantite,
                &p.date.jour, &p.date.mois, &p.date.annee,
                &p.date2.jour, &p.date2.mois, &p.date2.annee, &p.seuil) == 13) {

        if (strcmp(p.nom, nomProduit) == 0) {
            trouve = 1;
            printf("\nProduit trouv�. Entrez les nouvelles informations:\n");

            printf("Nouveau prix (actuel: %.2f): ", p.prix);
            scanf("%f", &p.prix);

            printf("Nouvelle quantit� (actuelle: %d): ", p.quantite);
            scanf("%d", &p.quantite);

            printf("Nouveau seuil (actuel: %.2f): ", p.seuil);
            scanf("%f", &p.seuil);
        }

        fprintf(temp, "%d,%s,%s,%s,%.2f,%d,%02d/%02d/%04d,%02d/%02d/%04d,%.2f\n",
                p.id, p.nom, p.description, p.nom_u, p.prix, p.quantite,
                p.date.jour, p.date.mois, p.date.annee,
                p.date2.jour, p.date2.mois, p.date2.annee, p.seuil);
    }

    fclose(f);
    fclose(temp);

    if (trouve) {
        if (remove(fichier) == 0 && rename("temp.csv", fichier) == 0) {
            printf("Produit modifi� avec succ�s.\n");
        } else {
            printf("Erreur lors de la modification du produit.\n");
        }
    } else {
        printf("Produit non trouv�.\n");
        remove("temp.csv");
    }
}

void supprimerProduit(const char* fichier, char* nomProduit) {
    FILE* f = fopen(fichier, "r");
    if (f == NULL) {
        printf("Erreur: Impossible d'ouvrir le fichier %s\n", fichier);
        return;
    }

    FILE* temp = fopen("temp.csv", "w");
    if (temp == NULL) {
        printf("Erreur: Impossible de cr�er le fichier temporaire\n");
        fclose(f);
        return;
    }

    produit p;
    int trouve = 0;

    while (fscanf(f, "%d,%[^,],%[^,],%[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
                &p.id, p.nom, p.description, p.nom_u, &p.prix, &p.quantite,
                &p.date.jour, &p.date.mois, &p.date.annee,
                &p.date2.jour, &p.date2.mois, &p.date2.annee, &p.seuil) == 13) {

        if (strcmp(p.nom, nomProduit) != 0) {
            fprintf(temp, "%d,%s,%s,%s,%.2f,%d,%02d/%02d/%04d,%02d/%02d/%04d,%.2f\n",
                    p.id, p.nom, p.description, p.nom_u, p.prix, p.quantite,
                    p.date.jour, p.date.mois, p.date.annee,
                    p.date2.jour, p.date2.mois, p.date2.annee, p.seuil);
        } else {
            trouve = 1;
        }
    }

    fclose(f);
    fclose(temp);

    if (trouve) {
        if (remove(fichier) == 0 && rename("temp.csv", fichier) == 0) {
            printf("Produit supprim� avec succ�s.\n");
        } else {
            printf("Erreur lors de la suppression du produit.\n");
        }
    } else {
        printf("Produit non trouv�.\n");
        remove("temp.csv");
    }
}

void rechercherProduit(const char* fichier, char critere[],int option) {
    FILE* f = fopen(fichier, "r");
    if (f == NULL) {
        printf("Erreur: Impossible d'ouvrir le fichier %s\n", fichier);
        return;
    }

    produit p;
    int trouve = 0;

    while (fscanf(f, "%d,%[^,],%[^,],%[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
                &p.id, p.nom, p.description, p.nom_u, &p.prix, &p.quantite,
                &p.date.jour, &p.date.mois, &p.date.annee,
                &p.date2.jour, &p.date2.mois, &p.date2.annee, &p.seuil) == 13) {

        if (!strcmp(p.nom, critere)&&option==1||!strcmp(p.nom_u, critere)&&option==2){
            trouve = 1;
            printf("\n--- Produit trouv� ---\n");
            printf("ID: %d\n", p.id);
            printf("Nom: %s\n", p.nom);
            printf("Description: %s\n", p.description);
            printf("Utilisateur: %s\n", p.nom_u);
            printf("Prix: %.2f\n", p.prix);
            printf("Quantit�: %d\n", p.quantite);
            printf("Date d'entr�e: %02d/%02d/%04d\n", p.date.jour, p.date.mois, p.date.annee);
            printf("Date de sortie: %02d/%02d/%04d\n", p.date2.jour, p.date2.mois, p.date2.annee);
            printf("Seuil: %.2f\n", p.seuil);
            printf("-------------------------\n");
        }
    }

    if (!trouve) {
        printf("Aucun produit trouv� avec ce crit�re.\n");
    }

    fclose(f);
}

void afficherListeProduits(const char* fichier) {
    FILE* f = fopen(fichier, "r");
    if (f == NULL) {
        printf("Erreur: Impossible d'ouvrir le fichier %s\n", fichier);
        return;
    }

    produit p;
    // Lire chaque ligne jusqu'� la fin du fichier
    while (fscanf(f, "%d,%99[^,],%199[^,],%99[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
            &p.id, p.nom, p.description, p.nom_u, &p.prix, &p.quantite,
            &p.date.jour, &p.date.mois, &p.date.annee,
            &p.date2.jour, &p.date2.mois, &p.date2.annee, &p.seuil) == 13) {  // 13 �l�ments attendus par produit

        printf("\n--- Produit ID: %d ---\n", p.id);
        printf("Nom: %s\n", p.nom);
        printf("Description: %s\n", p.description);
        printf("Utilisateur: %s\n", p.nom_u);
        printf("Prix: %.2f\n", p.prix);
        printf("Quantit�: %d\n", p.quantite);
        printf("Date d'entr�e: %02d/%02d/%04d\n", p.date.jour, p.date.mois, p.date.annee);
        printf("Date de sortie: %02d/%02d/%04d\n", p.date2.jour, p.date2.mois, p.date2.annee);
        printf("Seuil: %.2f\n", p.seuil);
        printf("-------------------------\n");
    }

    if (feof(f)) {
        printf("Fin du fichier atteinte.\n");
    } else {
        printf("Erreur de lecture dans le fichier.\n");
    }

    fclose(f);
}


void trierParNom(const char* fichier) {
    produit produits[100];
    int n = lireProduits(fichier, produits);

    // Tri � bulles sur les noms
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (strcmp(produits[j].nom, produits[j + 1].nom) > 0) {
                produit temp = produits[j];
                produits[j] = produits[j + 1];
                produits[j + 1] = temp;
            }
        }
    }

    // Affichage des produits tri�s
    printf("\nProduits tri�s par nom :\n");
    for (int i = 0; i < n; i++) {
        printf("ID: %d, Nom: %s, Prix: %.2f, Quantit�: %d\n",
               produits[i].id, produits[i].nom, produits[i].prix, produits[i].quantite);
    }
}

int trierParPrix(const char* fichier) {
    FILE* f = fopen(fichier, "r");
    if (f == NULL) {
        printf("Erreur d'ouverture du fichier %s\n", fichier);
        return 0;
    }

    produit produits[100];
    int i = 0;

    // Lire les produits depuis le fichier
    while (fscanf(f, "%d,%99[^,],%199[^,],%99[^,],%f,%d,%d/%d/%d,%d/%d/%d,%f\n",
                  &produits[i].id,
                  produits[i].nom,
                  produits[i].description,
                  produits[i].nom_u,
                  &produits[i].prix,
                  &produits[i].quantite,
                  &produits[i].date.jour, &produits[i].date.mois, &produits[i].date.annee,
                  &produits[i].date2.jour, &produits[i].date2.mois, &produits[i].date2.annee,
                  &produits[i].seuil) == 13) {
        i++;
    }

    fclose(f);

    // Tri � bulles sur les prix
    for (int j = 0; j < i - 1; j++) {
        for (int k = 0; k < i - j - 1; k++) {
            if (produits[k].prix > produits[k + 1].prix) {
                produit temp = produits[k];
                produits[k] = produits[k + 1];
                produits[k + 1] = temp;
            }
        }
    }

    // Afficher les produits tri�s
    for (int j = 0; j < i; j++) {
        printf("\n--- Produit ID: %d ---\n", produits[j].id);
        printf("Nom: %s\n", produits[j].nom);
        printf("Description: %s\n", produits[j].description);
        printf("Utilisateur: %s\n", produits[j].nom_u);
        printf("Prix: %.2f\n", produits[j].prix);
        printf("Quantit�: %d\n", produits[j].quantite);
        printf("Date d'entr�e: %02d/%02d/%04d\n", produits[j].date.jour, produits[j].date.mois, produits[j].date.annee);
        printf("Date de sortie: %02d/%02d/%04d\n", produits[j].date2.jour, produits[j].date2.mois, produits[j].date2.annee);
        printf("Seuil: %.2f\n", produits[j].seuil);
        printf("-------------------------\n");
    }

    return i;
}
